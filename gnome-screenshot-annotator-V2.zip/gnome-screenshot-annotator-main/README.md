# 📸 Screenshot Annotator

Extensión para GNOME Shell 49 que agrega herramientas de anotación **directamente dentro del panel de captura de pantalla nativo** de GNOME. 
Sin ventanas separadas, sin apps externas — las herramientas aparecen integradas en la misma UI que se abre al presionar `PrintScreen`.

## 📋 Requisitos

- GNOME Shell **49**
- Fedora 43 (probado) o cualquier distro con GNOME 49
---

## 📦 Instalación

### Opción 1 — Script automático


# Instalar:
cd screenshot-annotator
bash install.sh


### Debes reiniciar sesion para ver la extensión!

---
## 🚀 Uso

1. Presiona `PrintScreen` — aparece el panel de captura de GNOME con la barra de herramientas de anotación integrada debajo de los botones Selección / Pantalla / Ventana.

2. **Selecciona una herramienta** haciendo clic en su botón — el cursor cambia a modo dibujo.

3. **Dibuja** sobre el preview de la captura.

4. **Guarda** con cualquiera de estas opciones:
   - Botón `●` (capturar)
   - `Enter`
   - `Ctrl+C` (copia al portapapeles)

5. La imagen guardada y el portapapeles contendrán la imagen **con las anotaciones aplicadas**.

## ⚙️ Configuración

Abre **GNOME Extensions → Screenshot Annotator → Configuración**:

- **Compresión PNG** — nivel 0 (archivo grande, más rápido) a 9 (archivo pequeño, más lento). Por defecto: 9.
- **Tamaño de bloque del pixelado** — de 4 px (fino) a 64 px (muy grueso). Por defecto: 4 px.

---
